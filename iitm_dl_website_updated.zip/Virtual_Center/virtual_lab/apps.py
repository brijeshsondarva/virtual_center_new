from django.apps import AppConfig


class VirtualLabConfig(AppConfig):
    name = 'virtual_lab'
