from django.contrib import admin

from virtual_lab.models import Slideshow, Teams

# Register your models here.
admin.site.register(Slideshow)
admin.site.register(Teams)